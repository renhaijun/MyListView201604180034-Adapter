package com.example.mylistviewbaseAdapter.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class ViewHolder {

	private SparseArray<View> mView;
	private View mContextView;
	private int mPosition;

	public ViewHolder(Context context, int layoutId, ViewGroup parent, int position) {
		this.mPosition = position;
		this.mView = new SparseArray<View>();
		this.mContextView = LayoutInflater.from(context).inflate(layoutId, parent, false);
		mContextView.setTag(this);
	}

	public View getContextView() {
		return mContextView;
	}

	public int getmPosition() {
		return mPosition;
	}

	public static ViewHolder getViewHolder(Context context, View convertView, int layoutId, ViewGroup parent, int position) {
		if (convertView == null) {
			return new ViewHolder(context, layoutId, parent, position);
		} else {
			ViewHolder holder = (ViewHolder) convertView.getTag();
			holder.mPosition = position;
			return holder;
		}
	}

	public <T extends View> T getView(int viewId) {
		View view = mView.get(viewId);
		if (view == null) {
			view = mContextView.findViewById(viewId);
			mView.put(viewId, view);
		}
		return (T) view;
	}

	public ViewHolder setText(int viewId, String text) {
		TextView tv = getView(viewId);
		tv.setText(text);
		return this;
	}

	public ViewHolder setImageResource(int viewId, int resId) {
		ImageView view = getView(viewId);
		view.setImageResource(resId);
		return this;
	}

	public ViewHolder setImageBitmap(int viewId, Bitmap bitmap) {
		ImageView view = getView(viewId);
		view.setImageBitmap(bitmap);
		return this;
	}

	public ViewHolder setImageUrl(int viewId, String url) {
		ImageView view = getView(viewId);
		// ImageLoader.getInstance().loadImg(view,url);
		return this;
	}

}
