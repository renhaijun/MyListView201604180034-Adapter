package com.example.mylistviewbaseAdapter.bean;

public class Bean {
	private String titleStr;
	private String desStr;
	private String dateStr;
	private boolean isChecked;

	public boolean isChecked() {
		return isChecked;
	}

	public void setChecked(boolean isChecked) {
		this.isChecked = isChecked;
	}

	public String getTitleStr() {
		return titleStr;
	}

	public void setTitleStr(String titleStr) {
		this.titleStr = titleStr;
	}

	public String getDesStr() {
		return desStr;
	}

	public void setDesStr(String desStr) {
		this.desStr = desStr;
	}

	public String getDateStr() {
		return dateStr;
	}

	public void setDateStr(String dateStr) {
		this.dateStr = dateStr;
	}

	@Override
	public String toString() {
		return "Bean [titleStr=" + titleStr + ", desStr=" + desStr + ", dateStr=" + dateStr + "]";
	}

}
