package com.example.mylistview;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.ListView;

import com.example.mylistviewbaseAdapter.bean.Bean;
import com.example.mylistviewbaseAdapter.util.CommentAdapter;
import com.example.mylistviewbaseAdapter.util.ViewHolder;

public class MainActivity extends Activity {

	private ListView mListView;
	private List<Bean> lists;

	// private MyAdapter adapter;// 传统的adapter

	// private MyAdapterWithComment mMyAdapterWithComment;// 万能适配器的adapter，通用的adapter

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_layout);
		initView();
		initBean();
	}

	private void initBean() {
		lists = new ArrayList<Bean>();
		Bean mBean = null;
		for (int i = 0; i < 20; i++) {
			mBean = new Bean();
			mBean.setTitleStr("我的测试ListView" + i);
			mBean.setDateStr("2016-" + i);
			mBean.setDesStr("ListView测试" + i);
			lists.add(mBean);
		}
		initData();
	}

	private void initData() {
		runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// if (mMyAdapterWithComment == null) {
				// adapter = new MyAdapter(getApplicationContext(), lists);//传统的apapter
				// mMyAdapterWithComment = new MyAdapterWithComment(getApplicationContext(), R.layout.item_listview, lists);//
				// 万能适配器，通用的。
				// mListView.setAdapter(mMyAdapterWithComment);
				mListView.setAdapter(new CommentAdapter<Bean>(MainActivity.this, R.layout.item_listview, lists) {// 更加优化

							@Override
							public void convert(ViewHolder holder, final Bean bean) {
								holder.setText(R.id.tv_title, bean.getTitleStr()).setText(R.id.tv_desc, bean.getDesStr()).setText(R.id.tv_date, bean.getDateStr());
								// ((TextView) holder.getView(R.id.tv_title)).setText(bean.getTitleStr());
								// ((TextView) holder.getView(R.id.tv_desc)).setText(bean.getDesStr());
								// ((TextView) holder.getView(R.id.tv_date)).setText(bean.getDateStr());
								final CheckBox cBox = holder.getView(R.id.cb);
								cBox.setChecked(bean.isChecked());
								cBox.setOnClickListener(new OnClickListener() {

									@Override
									public void onClick(View v) {
										bean.setChecked(cBox.isChecked());
									}
								});
							}

						});
				// } else {
				// mMyAdapterWithComment.notifyDataSetChanged();
				// }
			}
		});
	}

	private void initView() {
		mListView = (ListView) findViewById(R.id.listView);
	}

}
