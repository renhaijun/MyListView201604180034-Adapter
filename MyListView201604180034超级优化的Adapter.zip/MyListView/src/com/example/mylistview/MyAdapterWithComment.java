package com.example.mylistview;

import java.util.List;

import android.content.Context;

import com.example.mylistviewbaseAdapter.bean.Bean;
import com.example.mylistviewbaseAdapter.util.CommentAdapter;
import com.example.mylistviewbaseAdapter.util.ViewHolder;

public class MyAdapterWithComment extends CommentAdapter<Bean> {

	public MyAdapterWithComment(Context context, int layoutId, List<Bean> datas) {
		super(context, mLayoutId, datas);
	}

	@Override
	public void convert(ViewHolder holder, Bean bean) {
		// ((TextView) holder.getView(R.id.tv_title)).setText(bean.getTitleStr());
		holder.setText(R.id.tv_title, bean.getTitleStr()).setText(R.id.tv_desc, bean.getDesStr()).setText(R.id.tv_date, bean.getDateStr());
		// ((TextView) holder.getView(R.id.tv_desc)).setText(bean.getDesStr());
		// ((TextView) holder.getView(R.id.tv_date)).setText(bean.getDateStr());
	}
}
